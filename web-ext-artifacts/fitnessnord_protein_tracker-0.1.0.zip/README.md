# FitnessNord Protein Tracker

Firefox extension that annotates FitnessNord offer cards with estimated protein grams per DKK.

It runs on:

```text
https://www.fitnessnord.com/tilbud*
```

The query string after `?` is not required. Matching `/tilbud*` catches the campaign URL and the plain offer page.

## How it works

The listing HTML has product URL and price, but usually not enough nutrition data. The content script therefore:

1. Reads each product card price.
2. Opens the linked FitnessNord product page with `fetch`.
3. Reads the `Protein` row from the nutrition table when it exists.
4. Converts the nutrition value to total protein in the listed product package, for example `20 x 45 g`.
5. Falls back to explicit serving text, for example `18 g protein pr. bar`.
6. Adds a small badge beside the price, for example `(2,58p/DKK)`.

Some products will show `protein ukendt` if the product page does not expose protein in parseable text.

The fixed `Protein` button opens a page menu with:

- `Beregn alle` to trigger calculation for loaded product cards.
- `Gå til bedst` to scroll to the highest protein-per-DKK product.
- A minimum `p/DKK` threshold for the ranked list.
- A checkbox to hide products below the threshold and products with unknown protein.
- A checkbox to sort the visible product cards by protein per DKK, best first.

## Development

Enter the dev shell:

```sh
nix develop
```

Run the extension in Firefox:

```sh
web-ext run --firefox=firefox --source-dir=.
```

Build a zip:

```sh
web-ext build --source-dir=.
```

For manual loading, open `about:debugging#/runtime/this-firefox`, choose **Load Temporary Add-on**, and select `manifest.json`.
